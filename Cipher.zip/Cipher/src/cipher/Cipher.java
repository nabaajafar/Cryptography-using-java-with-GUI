package cipher;

import javax.swing.JFrame;

public class Cipher {

    public static void main(String[] args) {

        Home h = new Home();
        h.setVisible(true);
        h.setSize(600, 300);
        h.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        h.setLocationRelativeTo(null);
        h.setResizable(false);
        
    }
    
}
